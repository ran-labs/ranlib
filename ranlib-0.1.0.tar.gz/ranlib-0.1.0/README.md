# ran

RAN Library

NOTE: DELETE `ranlib/ranlib.py` IN PROD

## Philosophy & Tenants

For any paper:

- EASY install
- EASY use
- EASY upload

- No BS
- No strings attached
- No extra setup needed

Just drop-in and start using it

## Info for Users

- Users of ranlib who use other papers will have to use pixi (setup is automatic)
- However, if all you wanna do is publish your implementation of a paper, pixi will try to be as invisible as possible

## Setup

This project uses pixi[https://pixi.sh]

```
pixi install
```
