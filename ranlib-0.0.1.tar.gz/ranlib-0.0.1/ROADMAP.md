# Roadmap

This roadmap is not necessarily for TODOs, but for some things we wanna put on the backlog.

- [ ] Rename this library (not RANLib). Ideally it will just be `ran`.
