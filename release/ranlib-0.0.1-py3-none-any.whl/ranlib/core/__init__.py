"""
Everything in this section (core/) is about how a producer with ran would use it
This includes:
    - syntax
    - compilation/transpilation
    - and all that jazz
"""
