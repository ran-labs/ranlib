## GENERATED CODE ##
## DO NOT MODIFY DIRECTLY ##

from typing import List


DEPENDENCIES_NAMES: List[str] = ['typer', 'pydantic', 'tomli', 'tomli-w', 'gitpython', 'rich', 'httpx']