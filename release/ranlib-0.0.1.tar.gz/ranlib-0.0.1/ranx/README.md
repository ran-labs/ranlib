# ranx

Another CLI for ranlib to interface with (don't wanna piss off users, so ranlib is de-bloated)

**NOTE: This is designed to be installed via pipx. This is so that users need only install it on their system one time and that's it.**
